#!/bin/bash

# 物流查价系统部署脚本
# 此脚本用于在服务器上部署项目

# 设置颜色
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${GREEN}开始部署物流查价系统...${NC}"

# 检查.env文件
if [ ! -f .env ]; then
  echo -e "${YELLOW}未找到.env文件，将使用.env.example创建${NC}"
  cp .env.example .env
  echo -e "${RED}请编辑.env文件，设置正确的环境变量！${NC}"
  exit 1
fi

# 安装依赖
echo -e "${YELLOW}安装依赖...${NC}"
npm install

# 生成Prisma客户端
echo -e "${YELLOW}生成Prisma客户端...${NC}"
npx prisma generate

# 应用数据库迁移
echo -e "${YELLOW}应用数据库迁移...${NC}"
npx prisma db push

# 初始化数据库
echo -e "${YELLOW}初始化数据库...${NC}"
node scripts/init-db.js

# 构建应用
echo -e "${YELLOW}构建应用...${NC}"
npm run build

echo -e "${GREEN}部署完成！${NC}"
echo -e "${YELLOW}您可以使用以下命令启动应用：${NC}"
echo "npm start"
echo ""
echo -e "${YELLOW}或者使用PM2进行管理：${NC}"
echo "pm2 start npm --name \"logistics-price-system\" -- start"
